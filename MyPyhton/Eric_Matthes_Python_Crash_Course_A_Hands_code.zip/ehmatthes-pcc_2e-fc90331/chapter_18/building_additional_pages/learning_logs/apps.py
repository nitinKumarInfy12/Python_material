from django.apps import AppConfig


class LearningLogsConfig(AppConfig):
    name = 'learning_logs'
