#!/usr/bin/env python

import sys
print(sys.argv)
print()

name = sys.argv[1]       # <1>
print("name is", name)

