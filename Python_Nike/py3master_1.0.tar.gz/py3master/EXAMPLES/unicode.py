#!/usr/bin/env python

print('we spent \u20ac1.23M for an original C\u00e9zanne') # <1>
print('26\u00B0')
print('26\N{DEGREE SIGN}') # <2>
print('26\u00B0')
print(r'26\u00B0\n')
print(r'26\N{DEGREE SIGN}') # <3>
print()

print("Romance in F\u266F Major")
print()

# Kubernetes

print("Kurbernetes (English)")
print(
    '\u039A\u03C5\u03B2\u03B5\u03C1'
    '\u03BD\u03AE\u03C4\u03B7\u03C3'
    ' (Greek)'
)
