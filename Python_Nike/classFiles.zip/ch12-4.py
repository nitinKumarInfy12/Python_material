#!/usr/bin/env python

class Person:

    def __init__(self, name, age):
        self.__name = name
        self.__age = age

    def sayHello(self):
        print('Hello {} - {}'.format(self.__name, self.__age))

    @classmethod
    def doWork(cls):
        print('Doing class work')
        print('cls = {}'.format(cls))

    def doOtherWork(self):
        print('Doing object work')
        print('self = {}'.format(self))

    @staticmethod
    def doYetMoreWork()
        print('Doing yet more work')

    @property
    def name(self):
        print('In name getter')
        return self.__name

    @name.setter
    def name(self, newName):
        print('In name setter')
        self.__name = newName

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, newAge):
        self.__age = newAge

p1 = Person('John Doe', 50)
p2 = Person('Sally Smith', 42)

p1.sayHello()
p2.sayHello()

p1.doWork()
p2.doWork()
p1.doOtherWork()
p2.doOtherWork()

p1.doYetMoreWork()
p2.doYetMoreWork()
