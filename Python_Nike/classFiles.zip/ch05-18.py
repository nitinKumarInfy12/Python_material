#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']

for sally, item in reversed(list(enumerate(aList))):
    print(sally, '=', item)
