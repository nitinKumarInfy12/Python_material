#!/usr/bin/env python

with open('DATA/parrot.txt', 'r') as fh:
    lines = fh.readlines()
    for line in lines:
        print(line[:-1])


print('The file is closed')
