#!/usr/bin/env python

data = int(input('Enter a number: '))

print('You entered:', data + 99)
