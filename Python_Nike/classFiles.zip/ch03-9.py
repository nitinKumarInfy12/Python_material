#!/usr/bin/env python

a = 65

print('dec = {0:d} oct = {0:#o} hex = {0:#x} char = {0:c} bin = {0:#b}'.format(a))
