#!/usr/bin/env python

class Greeter:

    def sayHello(self):
#        print('Hello {}'.format(self.name))
        print('self = {}'.format(self))

g = Greeter()
g2 = Greeter()

#g.name = 'Bob'
g2.name = 'Sally'

print('g = {}'.format(g))
print('g2 = {}'.format(g2))

g.sayHello()
g2.sayHello()


print(dir(g))
print('=' * 50)
print(dir(g2))
