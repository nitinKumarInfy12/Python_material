#!/usr/bin/env python

while True:
    num = input('Enter a temp: ')
    try:
        num = int(num)
    except Exception as err:
        print('Invalid number ', err)
        continue

    break

print('Doing something with num')
