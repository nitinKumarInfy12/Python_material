#!/usr/bin/env python

def doStuff(a, b=None, *c, **d):
    print('In doStuff')
    print('a = {} b = {} c = {} d = {}'.format(a, b, c, d))

def myPrint(*args, sep=' ', end='\n', file=None):
    print('In myPrint')

aList = ['fe', 'fi', 'fo']
aDict = {'b':'v1', 'k2':'v2', 'k3':'v3'}

doStuff(42, aList)
doStuff(42, *aList)
doStuff(42, **aDict)
