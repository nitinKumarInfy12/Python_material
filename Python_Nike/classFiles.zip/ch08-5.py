#!/usr/bin/env python

def add(a, b):
    return int(a) + int(b)

def sub(a, b):
    return int(a) - int(b)

def default(a, b):
    return 'Not supported'

opCodes =  { '+' : add,
             '-' : sub }

exp = input('Enter an expression: ')
num1, op, num2 = exp.split()

#print(opCodes)

func = opCodes.get(op, default)
result = func(num1, num2)

print('{} {} {} = {}'.format(num1, op, num2, result))
