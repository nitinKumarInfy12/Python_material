#!/usr/bin/env python

a = 42

def doStuff():
    global a
    a = 99
    print('In doStuff a = {}'.format(a))

def doOtherStuff():
    print('In doOtherStuff a = {}'.format(a))
    return 199

print('Global a = {}'.format(a))
doStuff()
a = doOtherStuff()
print('Global a = {}'.format(a))
