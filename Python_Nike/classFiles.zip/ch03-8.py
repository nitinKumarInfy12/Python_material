#!/usr/bin/env python

a = 42
b = 3.1415
c = 'hello'

result = 'a = |{0:<5d}| b = |{1:>8.3f}| c = |{2:^10s}|'.format(a, b, c)

print(result)
