#!/usr/bin/env python

import re

data = 'Today is: 4/11/2019'

result = re.search(r'(\d{1,2})/(\d{1,2})/(\d{4})', data)

print(result.group())
print('Month:', result.group(1))
print('Day:', result.group(2))
print('Year:', result.group(3))
