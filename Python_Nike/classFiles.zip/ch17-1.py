#!/usr/bin/env python

from collections import namedtuple

Foo = namedtuple('Foo', 'bar baz')

f = Foo('junk', 'stuff')

print(f.bar)
print(f[1])

print(type(Foo))
