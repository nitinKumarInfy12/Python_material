#!/usr/bin/env python

import time

print(time.time())
