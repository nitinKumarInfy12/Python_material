#!/usr/bin/env python

class Grandparent:

    def __init__(self):
        print('Initializing Grandparent')

    def doGrandparentStuff(self):
        print('Doing Grandparent Stuff in Grandparent')

class Parent(Grandparent):

    def __init__(self):
        Grandparent.__init__(self)
        print('Initializing Parent')

    def doParentStuff(self):
        print('Doing Parent Stuff in Parent')

class Child(Parent):

    def __init__(self):
        super().__init__()
        print('Initializing Child')

    def doChildStuff(self):
        print('Doing Child Stuff in Child')

    def doParentStuff(self):
        Parent.doParentStuff(self)
        print('Doing Parent Stuff in Child')

c = Child()

c.doChildStuff()
c.doParentStuff()
c.doGrandparentStuff()
