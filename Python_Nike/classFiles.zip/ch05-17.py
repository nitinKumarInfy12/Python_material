#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']
bList = [42, 99, 162, None]

cList = zip(aList, bList)

#print(cList)

for item in cList:
    print(item)
