#!/usr/bin/env python

import stuff

print(dir())
print('=' * 50)
print(dir(stuff))

stuff.doStuff()
