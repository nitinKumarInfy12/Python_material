#!/usr/bin/env python

import struct

aVar = 42
bVar = 3.1415
cVar = 'Hello'

rec = struct.pack('>i f 10s', aVar, bVar, cVar.encode())

with open('myData.bin', 'wb') as fh:
    fh.write(rec)
