#!/usr/bin/env python

def func1():
    print('In func1()')

def func2():
    print('In func2()')

def doStuff(parm1):
    print('In doStuff')
    parm1()

doStuff(func1)
doStuff(func2)
