#!/usr/bin/env python

cnt = 0

while cnt < 10:
    cnt += 1
    if cnt == 5:
        break 
    print('In while cnt = {}'.format(cnt))

print('Done!')
