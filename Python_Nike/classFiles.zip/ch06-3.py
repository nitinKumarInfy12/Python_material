#!/usr/bin/env python

with open('DATA/parrot.txt', 'r') as fh:
    for line in fh:
        print(line[:-1])

print('The file is closed')
