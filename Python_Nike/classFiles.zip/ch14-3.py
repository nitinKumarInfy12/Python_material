#!/usr/bin/env python

import os

result = os.popen('netstat -an')

for line in result:
    print(line[:-1])
