#!/usr/bin/env python

class Person:

    def __init__(self, name, age):
        self.__name = name
        self.__age = age

    def sayHello(self):
        print('Hello {} - {}'.format(self.__name, self.__age))

    @property
    def name(self):
        print('In name getter')
        return self.__name

    @name.setter
    def name(self, newName):
        print('In name setter')
        self.__name = newName

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, newAge):
        self.__age = newAge

p1 = Person('John Doe', 50)
p2 = Person('Sally Smith', 42)

p1._Person__name = 'Bob Johnson'

print(dir(p1))

print(p1.name)
#print(p2.name)
