#!/usr/bin/env python

opCodes = { '+' : lambda a, b : int(a) + int(b),
            '-' : lambda a, b : int(a) - int(b) }

exp = input('Enter an expression: ')
num1, op, num2 = exp.split()

func = opCodes.get(op, lambda a, b : 'Not supported') 
result = func(num1, num2)

print('{} {} {} = {}'.format(num1, op, num2, result))
