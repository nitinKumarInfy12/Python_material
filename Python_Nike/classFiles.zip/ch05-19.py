#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']
bList = ['foo', 'bar', 'baz']

aList += bList
print(aList)

flags = '=' * 10
print(flags)
