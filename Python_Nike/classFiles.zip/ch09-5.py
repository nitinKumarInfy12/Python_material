#!/usr/bin/env python

nerds = [
('Mark', 'Zuckerberg', 'Facebook'),
('Guido', 'Van Rossum', 'Python'),
('Larry', 'Wall', 'Perl'),
('Bill', 'Joy', 'Sun'),
('Bill', 'Gates', 'Microsoft'),
('Steve', 'Case', 'AOL'),
('Larry', 'Ellison', 'Oracle'),
('Steve', 'Jobs', 'Apple'),
('Dennis', 'Ritchie', 'Unix'),
]

for n in sorted(nerds, key=lambda item : (item[1], item[0])):
    print(n)
