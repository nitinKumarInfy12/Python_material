#!/usr/bin/env python

aStr = 'abcdefghijklmnopqrstuvwxyz'

print(aStr[::2])
print(aStr[1::2])
print(aStr[::-1])
print(aStr[:-1])
