#!/usr/bin/env python

import sqlite3 as db

conn = db.connect('DATA/PRESIDENTS')

cur = conn.cursor()

cur.execute('SELECT * FROM presidents')

lbls = [ item[0] for item in cur.description ]

data = cur.fetchone()

row = dict(zip(lbls, data))

print(row)
