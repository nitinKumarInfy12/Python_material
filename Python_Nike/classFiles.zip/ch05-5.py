#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']

data = aList[2:]

print(data)
