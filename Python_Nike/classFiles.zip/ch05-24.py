#!/usr/bin/env python

suits = 'C D H S'.split()
ranks = (2, 3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A')

cards = ( (rank, suit) for suit in suits for rank in ranks )

print(cards)

for card in cards:
    print(card)
