#!/usr/bin/env python

from knight import Knight

knights = {}

with open('DATA/knights.txt') as fh:
    for rec in fh:
        knight = Knight(rec)
        knights[knight.name] = knight

for k, v in knights.items():
    print(v)
