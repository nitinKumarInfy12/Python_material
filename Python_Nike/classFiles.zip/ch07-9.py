#!/usr/bin/env python

aSet = {'a', 'b', 'c', 'd'}
bSet = {'c', 'd', 'e', 'f'}


print('aSet =', aSet)
print('bSet =', bSet)

cSet = aSet - bSet
print('cSet =', cSet)

dSet = aSet & bSet
print('dSet =', dSet)

eSet = aSet | bSet
print('eSet =', eSet)

fSet = aSet ^ bSet
print('fSet =', fSet)
