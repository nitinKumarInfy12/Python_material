#!/usr/bin/env python

a = 42
b = 3.1415
c = 'hello'

result = 'a = |%5d| b = |%6.3f| c = |%-10s|' % (a, b, c)

print(result)
