#!/usr/bin/env python

aDict = {'k1':'v1', 'k2':'v2', 'k3':'v3'}

print('k2' in aDict)
print('k42' in aDict)

print(aDict.get('k2'))
print(aDict.get('k42', 'Default'))

print(aDict)

print('=' * 50)

print(aDict.setdefault('k2'))
print(aDict.setdefault('k42', 'Default'))

print(aDict)

del aDict['k99']
