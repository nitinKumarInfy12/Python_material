#!/usr/bin/env python

aList = [ [42, 99], ['fe', 'fi'] ]

print(aList[0][1])
