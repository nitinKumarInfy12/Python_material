#!/usr/bin/env python

import pickle
from knight import Knight

with open('DATA/knights.txt') as fh:
    rec = fh.readline()
    k = Knight(rec)

with open('knight.pic', 'wb') as of:
    pickle.dump(k, of)

