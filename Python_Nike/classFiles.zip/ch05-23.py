#!/usr/bin/env python

fh = open('DATA/passwd')
data = fh.readlines()

records = [ rec.split(':')[0] for rec in data if '/bin/bash' not in rec ]

for item in records:
    print(item)
