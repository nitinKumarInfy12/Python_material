#!/usr/bin/env python

with open('DATA/parrot.txt', 'r') as fh:
    line = fh.readline()
    while line:
        print(line[:-1])
        line = fh.readline()    

print('The file is closed')
