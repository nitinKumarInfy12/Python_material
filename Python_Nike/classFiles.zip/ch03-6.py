#!/usr/bin/env python

aVar = 'hello'

aList = ['fe', 'fi', 'fo', 'fum']

print(dir(aVar))

result = ':'.join(aList)

print(result)

data = result.split(':')

print(data)
