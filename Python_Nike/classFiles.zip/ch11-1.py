#!/usr/bin/env python

import myMod

print(dir())
print('=' * 50)
print(dir(myMod))

myMod.doStuff()
print(myMod.aVar)

print(myMod.__doc__)
