#!/usr/bin/env python

data = int(input('Enter a number: '))

if data > 10:
    print('Big')
elif data > 5:
    print('Medium')
else:
    print('Small')
