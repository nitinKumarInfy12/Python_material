#!/usr/bin/env python

def func1():
    print('In func1')
    return False

def func2():
    print('In func2')
    return True

if func1() or func2():
    print('True')
else:
    print('False')



