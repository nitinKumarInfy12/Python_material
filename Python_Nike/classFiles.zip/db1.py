#!/usr/bin/env python

import sqlite3 as db

conn = db.connect('DATA/PRESIDENTS')

cur = conn.cursor()

cur.execute('SELECT * FROM presidents')

row = cur.fetchone()

while row:
    print(row)
    row = cur.fetchone()
