#!/usr/bin/env python

counts = {}

with open('DATA/passwd') as fh:
    for rec in fh:
        shell = rec[:-1].split(':')[-1]
        shell = 'Empty' if not shell else shell
        counts[shell] = counts.get(shell, 0) + 1

for shell, cnt in counts.items():
    print('{} has {} users'.format(shell, cnt))
