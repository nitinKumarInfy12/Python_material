#!/usr/bin/env python

import pickle

with open('knight.pic', 'rb') as fh:
    k = pickle.load(fh)
    print(k)
