#!/usr/bin/env python

import struct

with open('myData.bin', 'rb') as fh:
    data = fh.read()

flds = struct.unpack('>i f 10s', data)

print(flds)
