#!/usr/bin/env python

class MikesError(Exception):
    pass

def doStuff(a, b):
    if not isinstance(a, (int, float)):
        err = MikesError('parm a must be an int or float')
        raise err
    if not isinstance(b, (int, float)):
        raise MikesError('parm b must be an int or float')

    print('Doing something with a and b')

try:
    doStuff(42, 99)
    doStuff(42, 'hello')

except MikesError as err:
    print(err)
