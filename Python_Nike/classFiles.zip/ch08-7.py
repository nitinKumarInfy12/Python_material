#!/usr/bin/env python

def player(name):
    def score():
        print('{} scored'.format(name))
    return score

p1 = player('Bob')
p2 = player('Sally')

p1()
p2()
p1()
p1()
p2()
p2()
