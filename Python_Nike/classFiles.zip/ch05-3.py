#!/usr/bin/env python

aStr = 'hello'

print(aStr[0])
print(aStr[-1])
