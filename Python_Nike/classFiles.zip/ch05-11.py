#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']

a, b, c, d  = aList

print('a = {} b = {} c = {} d = {}'.format(a, b, c, d))

