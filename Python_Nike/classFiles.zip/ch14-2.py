#!/usr/bin/env python

import os

os.system('ls -l')

print('Back in python')
