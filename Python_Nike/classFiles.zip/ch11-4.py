#!/usr/bin/env python

import sys

sys.path.append('./stuff')

from myMod import *

doStuff()

for p in sys.path:
    print(p)
