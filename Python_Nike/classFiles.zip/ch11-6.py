#!/usr/bin/env python

from stuff import *

print(dir())

