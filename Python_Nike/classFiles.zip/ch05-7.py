#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']

aList[1:1] = ['foo', 'bar', 'baz']

print(aList[::-1])
