#!/usr/bin/env python

from datetime import *

today = date.today()
xmas = date(2019, 12, 25)

print(today)

daysUntil = xmas - today

print(daysUntil)

nextWeek = timedelta(21)

then = today + nextWeek
print(then)
