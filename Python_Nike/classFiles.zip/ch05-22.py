#!/usr/bin/env python

aList = ['fe', 'fi', 42, 99, 3.1415, 'fo', 'fum']

nums = [ item for item in aList if isinstance(item, (int, float) ]

print(nums)
