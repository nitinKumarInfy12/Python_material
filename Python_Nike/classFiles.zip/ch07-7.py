#!/usr/bin/env python

lbls = 'userId passwd ui gid fullName home shell'.split()

with open('DATA/passwd') as fh:
    users = { line.split(':')[0] : dict(zip(lbls, line.split(':'))) for line in fh if line[:-1].endswith('/bin/bash') }

uid = input('Enter a user to look up: ')

print(users[uid]['home'])
