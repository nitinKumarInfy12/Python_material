from stuff.myMod import *
