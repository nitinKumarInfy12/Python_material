#!/usr/bin/env python

'''
This is a doc string
Line 2
Line 3
'''

aVar = 'hello'
_bVar = 42

def doStuff():
    '''
    This is a how to use doStuff

    More on doStuff
    Blah blah blah
    '''
    print('In myMod::doStuff')
    print('aVar = {}'.format(aVar))

print(__name__)

