#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum', 'foo']

print(aList[1])
print(aList[-1])

print('There are {} elements in the list'.format(len(aList)))

