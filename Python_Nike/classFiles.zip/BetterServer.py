#!/usr/bin/env python

import socketserver as SocketServer

class MyServer(SocketServer.BaseRequestHandler):

    def handle(self):
        print("Client on ", self.client_address, " called")
        try:
            while True:
                data = self.request.recv(4096) 
                if (not data):
                    break
                else:
                    print("Recieved: ", data.decode())
            
                self.request.sendall("Thanks\n".encode()) 
        except:
            print('Handle exception here')

        finally:
            self.request.close()
        
server = SocketServer.ThreadingTCPServer(('', 4000), MyServer)
server.serve_forever()
