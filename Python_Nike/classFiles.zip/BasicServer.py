#!/usr/bin/env python

import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
sock.bind(('', 4000))
sock.listen(5) 

try:
    while True:
        newSocket, address = sock.accept()  
        
        print("Client on ", address, " called")
        
        while True:
            data = newSocket.recv(4096) 
            if (not data):  
                break;
            else:
                print("Recieved: ", data.decode())
            
            newSocket.sendall("Thanks\n".encode()) 
            
        newSocket.close()
        
finally:
     sock.close()
