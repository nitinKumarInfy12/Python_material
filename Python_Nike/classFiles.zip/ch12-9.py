#!/usr/bin/env python

class Worker:

    def doStuff(self):
        print('Doing stuff')


w1 = Worker()
w2 = Worker()

w1.doStuff()
w2.doStuff()

def blah(self):
    print('Doing other stuff')

Worker.doOtherStuff = blah

w1.doOtherStuff()
w2.doOtherStuff()
