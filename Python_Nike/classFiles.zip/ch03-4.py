#!/usr/bin/env python

aVar = """hello
world"""

print(aVar)

