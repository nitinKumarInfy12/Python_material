#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum']

aList += ['foo', 'bar', 'baz']


aList.remove('fi')

del aList[1]

print(aList)

