#!/usr/bin/env python

aList = ['fe', 42, 99, 'fum']

a, b, c, d  = aList

print('a = {} b = {} c = {} d = {}'.format(a, b, c, d))

