#!/usr/bin/env python

def read_data():
    with open('DATA/mary.txt') as fh:
        for rec in fh:
            print('In read_data')
            yield rec


for rec in read_data():
    print(rec)
