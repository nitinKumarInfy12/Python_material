#!/usr/bin/env python

aVar = 'Hello'
bVar = 42

def doStuff():
    print('Doing stuff')

print(dir())

aVar = 3.1415

print(type(aVar))
print(type(bVar))
print(type(doStuff))
