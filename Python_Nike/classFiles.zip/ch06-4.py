#!/usr/bin/env python

data = ['line a', 'line b', 'line c']

with open('junk.txt', 'a') as fh:
    print('The file is open')
    print(*data, sep='\n', file=fh)
