#!/usr/bin/env python

a = 42
b = 99

a, b = b, a

print('a = {} b = {}'.format(a, b))
