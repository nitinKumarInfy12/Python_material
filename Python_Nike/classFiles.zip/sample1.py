#!/usr/bin/env python

import threading

def worker(name):
    for i in range(20):
        print('{} - {}'.format(name, i))

t1 = threading.Thread(target=worker, args=('Thread 1',))
t2 = threading.Thread(target=worker, args=('Thread 2',))

t1.start()
t2.start()

t1.join()
t2.join()

print('Main thread ending')
