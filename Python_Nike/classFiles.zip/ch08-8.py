#!/usr/bin/env python

def transactional(orig_func):
    def doInTrans(*args, **kw):
        print('Starting Transaction')
        print('args = {} kw = {}'.format(args, kw))
        result = orig_func(*args, **kw)
        print('Committing Transaction\n')
        return result
    return doInTrans

@transactional
def doComplexBusinessStuff(a, b):
    print('Doing complex stuff')
    print('a = {} b = {}'.format(a, b))

@transactional
def doMoreComplexBusinessStuff():
    print('Doing more complex stuff')

doComplexBusinessStuff(b=42, a=99)
doMoreComplexBusinessStuff()


