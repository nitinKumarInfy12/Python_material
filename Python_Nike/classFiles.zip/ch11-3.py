#!/usr/bin/env python

from myMod import *
import myMod

myMod.aVar = 'goodbye'

print(dir())

print(myMod._bVar)

print(myMod._bVar)
