#!/usr/bin/env python

import threading

count = 0

myLoc = threading.Lock()

class Worker(threading.Thread):

    def __init__(self, name):
        threading.Thread.__init__(self)
        self.__name = name

    def run(self):
        global count
        for i in range(10):
            with myLoc:
                print('{} - {}'.format(self.__name, count))
                count += 1

w1 = Worker('Thread 1')
w2 = Worker('Thread 2')

#w1.setDaemon(True)
#w2.setDaemon(True)

w1.start()
w2.start()

w1.join()
w2.join()

print('Main Thread ending')
