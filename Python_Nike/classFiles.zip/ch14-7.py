#!/usr/bin/env python

from datetime import *

now = datetime.now()
xmas = datetime(2019, 12, 25, 0, 0, 0)

print(dir(now))

until = xmas - now

print(until)
