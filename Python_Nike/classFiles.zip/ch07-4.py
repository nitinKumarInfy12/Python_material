#!/usr/bin/env python

lbls = 'userId passwd uid gid fullName home shell'.split()

with open('DATA/passwd') as fh:
    rec = fh.readline()

record = dict(zip(lbls, rec.split(':')))

print(record['fullName'])
