#!/usr/bin/env python

import sys

print(sys.platform)

#for m in sys.modules:
#    print(m)
