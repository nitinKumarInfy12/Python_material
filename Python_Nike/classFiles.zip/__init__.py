import stuff.myMod

