#!/usr/bin/env python

aVar = 3.1415

aCpx = 1.0+2.0j

print(dir())

print(type(aCpx))

