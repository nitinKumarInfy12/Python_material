#!/usr/bin/env python

aTup = ('fe', 'fi', 'fo', 'fum', 'foo')

aTup = list(aTup)

aTup.append('bar')

aTup = tuple(aTup)

print(aTup)
