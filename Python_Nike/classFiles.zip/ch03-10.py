#!/usr/bin/env python

a = 10
b = 3

c, d = divmod(a, b)

print(c)
print(d)

e = a ** .5

print(e)
