#!/usr/bin/env python

class Money:

    def __init__(self, amt, curr):
        self.__amt = amt
        self.__curr = curr

    def __str__(self):
        return '{:.2f} - {}'.format(self.__amt, self.__curr)

    def __add__(self, other):
        if not isinstance(other, Money):
            raise TypeError('Can only add Money objects together')
        if self.__curr != other.__curr:
            raise ValueError('Cannot add dissimilar currencies')
        return Money(self.__amt + other.__amt, self.__curr)

    def __sub__(self, other):
        if not isinstance(other, Money):
            raise TypeError('Can only subtract Money objects together')
        if self.__curr != other.__curr:
            raise ValueError('Cannot subtract dissimilar currencies')
        return Money(self.__amt - other.__amt, self.__curr)

m1 = Money(9.99, 'USD')
m2 = Money(4.5, 'USD')

print(m1)
print(m2)

m3 = m1 + m2
print(m3)

m4 = m3 - m2
print(m4)
