#!/usr/bin/env python

import os.path

name = '/foo/bar/baz'

print(os.path.split(name))
print(os.path.basename(name))

print(os.path.expanduser('~'))
print(os.path.expanduser('~root'))
