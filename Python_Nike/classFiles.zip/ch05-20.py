#!/usr/bin/env python

r = range(0, 100, 5)

print(type(r))

for item in r:
    print(item)
