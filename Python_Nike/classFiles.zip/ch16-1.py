#!/usr/bin/env python

import os.path

print(os.path.expandvars('MAVEN is at: ${MAVEN_HOME}'))
