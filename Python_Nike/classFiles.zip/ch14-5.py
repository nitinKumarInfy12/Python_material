#!/usr/bin/env python

import  random

print(dir(random))


