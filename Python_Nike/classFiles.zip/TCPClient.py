#!/usr/bin/env python

import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
sock.connect(('localhost', 4000))

data = ("This is some data", "This is more data")
for line in data:
    sock.sendall(line.encode())
    response = sock.recv(4096)
    print("Sent: ", line)
    print("Server responded: ", response.decode())
    
sock.close()
