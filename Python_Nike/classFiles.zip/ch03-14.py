#!/usr/bin/env python

import sys

print(int(sys.argv[1]) + 10)
