#!/usr/bin/env python

aList = ['fe', 'fi', 'fo', 'fum', 'foo', 'bar', 'baz']

for item in aList:
    print(item)

aStr = 'Hello'

print()
for item in aStr:
    print(item)
