#!/usr/bin/env python

def doStuff(a, b=None, *c, **d):
    print('In doStuff')
    print('a = {} b = {} c = {} d = {}'.format(a, b, c, d))

doStuff(b=42, a=99)
doStuff(42)
doStuff(42, 99, 'foo', 'bar')
doStuff(42, 99, 'foo', 'bar', junk='hello', stuff='goodbye')
doStuff(42, 99, junk='hello', stuff='goodbye')
doStuff(42, junk='hello', stuff='goodbye')

