#!/usr/bin/env python

print('hello', 'world', end='', sep='>>>')
print('Next line')
