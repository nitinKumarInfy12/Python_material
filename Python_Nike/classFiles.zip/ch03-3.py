#!/usr/bin/env python

aVar = "hello"
bVar = 42

cVar = aVar + str(bVar)

print(cVar)
