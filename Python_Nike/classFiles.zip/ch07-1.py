#!/usr/bin/env python

aDict = {'k1':'v1', 'k2':'v2', 'k3':'v3'}

print(aDict['k2'])

aDict['k4'] = 'v4'
aDict['k2'] = 'update'

print(aDict)
