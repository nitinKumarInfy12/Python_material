#!/usr/bin/env python

def doStuff():
    print('In doStuff')

aVar = doStuff

doStuff()
aVar()

print(doStuff)
print(aVar)
