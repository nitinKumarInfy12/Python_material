#!/usr/bin/env python

aList = ['foo', 'bar', 'baz', 'junk', 'stuff']

for item in sorted(aList):
    print(item)

