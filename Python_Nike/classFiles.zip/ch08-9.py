#!/usr/bin/env python

def transactional(orig_func):
    def doInTrans(*args, **kw):
        print('orig_func = {}'.format(orig_func))
        print('args = {} kw = {}'.format(args, kw))
        result = orig_func(*args, **kw)
        print('\n')
        return result
    return doInTrans

@transactional
def doComplexBusinessStuff(a, b):
    print('Doing complex stuff')
    print('a = {} b = {}'.format(a, b))

@transactional
def doMoreComplexBusinessStuff():
    print('Doing more complex stuff')

print(doComplexBusinessStuff)
doComplexBusinessStuff(42, 99)


