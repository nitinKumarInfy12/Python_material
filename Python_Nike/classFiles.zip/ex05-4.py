#!/usr/bin/env python

limit = 100

primes = [True] * (limit + 1)

for num in range(2, limit+1):
    if primes[num]:
        print('{} is prime'.format(num))
        for m in range(num, limit+1, num):
            primes[m] = False
