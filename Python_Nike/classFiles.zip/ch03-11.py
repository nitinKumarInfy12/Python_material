#!/usr/bin/env python

a = 10
b = '3a'

c = a + int(b, 16)

print(c)
