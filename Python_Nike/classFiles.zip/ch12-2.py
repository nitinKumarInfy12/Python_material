#!/usr/bin/env python

class Person:
    count = 0


    def setName(self, name):
        self.name = name

    def __init__(self, name=None):
        self.name = name
        Person.count += 1

    def __del__(self):
        print('destroying a Person')
        Person.count -= 1

    def sayHello(this):
        print('Hello {}'.format(this.name))

p1 = Person()
p2 = Person('Sally Smith')
p3 = Person('Bob Smith')

p1.setName('John Doe')

p1.sayHello()
p2.sayHello()

p1 = None

print('There are {} Person objects in existance'.format(Person.count))

