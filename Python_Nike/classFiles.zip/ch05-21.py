#!/usr/bin/env python

aList = ['foo', 'bar', 'fe', 'fi', 'fo', 'fum', 'baz', 'junk', 'stuff']

bList = [ item.upper()  for item in aList if item[0] == 'b' ]

print(bList)
