#!/usr/bin/env python

data = int(input('Enter some data: '))

if data:
    print('True')
else:
    print('False')
