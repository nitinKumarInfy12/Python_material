#!/usr/bin/env python

def doStuff(a, b):
    try:
        print('Opening db')
        c = a + b
    except:
        print('There was an exception!')
        return

    finally:
        print('Closing db')

doStuff(42, 99)
doStuff(42, 'hello')

print('Back in the main app')

