#!/usr/bin/env python

aVar = 'The letter is \U00000118 \N{LATIN CAPITAL LETTER E WITH OGONEK}'

print(aVar)

bVar = '=' * 50

print(bVar)
