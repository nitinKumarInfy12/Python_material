#!/usr/bin/env python

lbls = 'userId passwd ui gid fullName home shell'.split()

users = {}

with open('DATA/passwd') as fh:
    for line in fh:
        user = dict(zip(lbls, line.split(':')))
        users[user['userId']] = user

uid = input('Enter a user to look up: ')

print(users[uid]['fullName'])
