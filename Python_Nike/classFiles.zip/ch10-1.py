#!/usr/bin/env python

a = 10
b = 'hello'
arr = []

try:
    print(arr[7])
    c = a / b
    print(c)

except (TypeError, IndexError) as err:
    print(type(err))
    print('There was a Type Error')
    quit()

print('After the exception')
