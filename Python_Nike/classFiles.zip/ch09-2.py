#!/usr/bin/env python

nums = [800, 80, 1000, 32, 255, 400, 5, 5000]

nums = sorted(nums, key=str)

print(nums)
