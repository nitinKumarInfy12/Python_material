#!/usr/bin/env python

aDict = {'k1':'v1', 'k2':'v2', 'k3':'v3'}

for k, v in aDict.items():
    print(k, '=>', v)
