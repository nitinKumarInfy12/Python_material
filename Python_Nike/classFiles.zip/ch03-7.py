#!/usr/bin/env python

aVar = 'hello World'

print(aVar.title())
