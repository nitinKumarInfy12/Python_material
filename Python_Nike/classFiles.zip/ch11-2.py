#!/usr/bin/env python


def doStuff():
    print('In global doStuff')

doStuff()

from myMod import doStuff

doStuff()
