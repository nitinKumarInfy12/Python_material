#!/usr/bin/env python

counts = {}

with open('DATA/breakfast.txt') as fh:
    for item in fh:
        item = item[:-1]
        counts[item] = counts.get(item, 0) + 1

for item, cnt in counts.items():
    print('{} occurs {} times'.format(item, cnt))
