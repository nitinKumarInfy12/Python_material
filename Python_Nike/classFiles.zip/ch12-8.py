#!/usr/bin/env python

class transactable:

    def __init__(self, meth):
        self.__meth = meth

    def __call__(self, *args, **kw):
        print('Starting transaction')
        print('args = {} kw = {}'.format(args, kw))
        try:
            result = self.__meth(*args, **kw)
            print('Commit transaction\n')
            return result

        except Exception as err:
            print('Rollback transaction\n')
            raise err

@transactable
def doStuff(a, b):
    print('Doing stuff with a and b')
    return a + b

print(doStuff)

doStuff(42, 99)
doStuff(b='hello', a=42)
